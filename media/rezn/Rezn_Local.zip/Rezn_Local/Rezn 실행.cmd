@echo off
chcp 65001 >nul
title Rezn 로컬 체험판
cd /d "%~dp0"
set "NODE_ENV="
set "PORT=3017"
set "HOST=127.0.0.1"
set "APP_ORIGIN=http://127.0.0.1:3017,http://localhost:3017"
set "COOKIE_SECURE=false"
set "APP_DATA_DIR=%~dp0app\.data\app"
set "CROCHE_DATA_DIR=%~dp0app\.data\croche"
set "CROCHE_PROJECT_KEY="
set "CROCHE_SERVER_KEY="
set "CROCHE_DEBUG_KEY="
set "REZN_LOCAL=1"
echo.
echo   Rezn 로컬 체험판 (AI 없이 실행)
echo   잠시 후 브라우저가 열립니다: http://127.0.0.1:3017
echo   끝내려면 이 창을 닫으세요.
echo.
start "" "http://127.0.0.1:3017/"
"%~dp0runtime\node.exe" "%~dp0app\apps\server\dist\index.js"
pause